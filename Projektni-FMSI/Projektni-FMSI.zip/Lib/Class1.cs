﻿using System;

namespace Lib
{
    public class Class1
    {
    }
}
