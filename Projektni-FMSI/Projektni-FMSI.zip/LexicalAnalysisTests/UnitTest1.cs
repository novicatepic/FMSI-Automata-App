using NUnit.Framework;
using Projektni_FMSI;

namespace LexicalAnalysisTests
{
    public class Tests
    {
        private LexicalAnalysis l;

        [SetUp]
        public void Setup()
        {
            
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}